# CTA-project
### Computational Thinking with Algorithm

This repository contains the Project 2020 for Module **'Computational Thinking with Algorithms'** at GMIT.

Karolina Szafran-Belzowska, 2020-04-25

How to run the Jupyter notebook The Jupyter Notebook App can be launched by clicking on the Jupyter Notebook icon installed by Anaconda in the start menu (Windows) or by typing in a terminal (cmd on Windows):

#### 'jupyter notebook'

This will launch a new browser window (or a new tab) showing the Notebook Dashboard, a sort of control panel that allows (among other things) to select which notebook to open. Taken from: Jupyter notebook

The Jupyter Notebook is an open-source web application that allows you to create and share documents that contain live code, equations, visualizations and narrative text. Uses include data cleaning and transformation, numerical simulation, statistical modeling, data visualization, machine learning, and much more.
